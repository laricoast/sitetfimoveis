<?php 
define('HOST', 'localhost');
define('USUARIO', 'root');
define('SENHA', '');
define('DB', 'tfimoveis');

 	$conexao = mysqli_connect(HOST, USUARIO, SENHA, DB) //porta, usuário, senha
    or die("Erro na conexão com banco de dados!"); //caso não consiga conectar mostra a mensagem de erro mostrada na conexão

?>