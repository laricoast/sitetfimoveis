<?php

include('conexao.php');

if(empty($_POST['nome']) || empty($_POST['email']) || empty($_POST['mensagem'])) {
	header('Location: index.html');
	exit();
}

$nome = mysqli_real_escape_string($conexao, $_POST['nome']);
$email = mysqli_real_escape_string($conexao, $_POST['email']);
$mensagem = mysqli_real_escape_string($conexao, $_POST['mensagem']);


$query = "INSERT INTO usuarios (id_usuario, nome, email, mensagem) values (NULL, '$nome', '$email', '$mensagem')";

$result = mysqli_query($conexao, $query);

?>
